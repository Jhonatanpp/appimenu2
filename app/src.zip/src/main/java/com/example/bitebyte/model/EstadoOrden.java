package com.example.bitebyte.model;

public enum EstadoOrden {
    PENDIENTE,
    EN_PREPARACION,
    LISTO_PARA_ENTREGAR,
    ENTREGADO,
    EN_PROCESO,
    COMPLETADA
}