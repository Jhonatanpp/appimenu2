package com.example.bitebyte.model;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.bitebyte.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.*;

public class FragmentPerfilUsuario extends Fragment {

    private EditText editNombrePerfil, editCorreoPerfil, editEdadPerfil;
    private Button btnGuardarPerfil;
    private DatabaseReference refUsuario;
    private String uid;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_perfil_usuario, container, false);

        editNombrePerfil = view.findViewById(R.id.editNombrePerfil);
        editCorreoPerfil = view.findViewById(R.id.editCorreoPerfil);
        editEdadPerfil   = view.findViewById(R.id.editEdadPerfil);
        btnGuardarPerfil = view.findViewById(R.id.btnGuardarPerfil);

        FirebaseAuth auth = FirebaseAuth.getInstance();
        FirebaseUser user = auth.getCurrentUser();
        if (user == null) {
            Toast.makeText(getContext(), "Sesión no iniciada", Toast.LENGTH_SHORT).show();
            return view;
        }
        uid = user.getUid();
        refUsuario = FirebaseDatabase.getInstance()
                .getReference("usuarios")
                .child(uid);

        cargarDatos();
        btnGuardarPerfil.setOnClickListener(v -> guardarCambios());

        return view;
    }

    private void cargarDatos() {
        refUsuario.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override public void onDataChange(@NonNull DataSnapshot snap) {
                Usuario u = snap.getValue(Usuario.class);
                if (u != null) {
                    editNombrePerfil.setText(u.getNombre());
                    editCorreoPerfil.setText(u.getCorreo());
                    editEdadPerfil.setText(String.valueOf(u.getEdad()));
                }
            }
            @Override public void onCancelled(@NonNull DatabaseError err) {
                Toast.makeText(getContext(), "Error al cargar perfil", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void guardarCambios() {
        String nombre = editNombrePerfil.getText().toString().trim();
        String correo = editCorreoPerfil.getText().toString().trim();
        String edadStr= editEdadPerfil.getText().toString().trim();

        if (TextUtils.isEmpty(nombre) || TextUtils.isEmpty(correo) || TextUtils.isEmpty(edadStr)) {
            Toast.makeText(getContext(), "Completa todos los campos", Toast.LENGTH_SHORT).show();
            return;
        }

        int edad;
        try { edad = Integer.parseInt(edadStr); }
        catch (NumberFormatException e) {
            Toast.makeText(getContext(), "Edad inválida", Toast.LENGTH_SHORT).show();
            return;
        }

        refUsuario.child("nombre").setValue(nombre);
        refUsuario.child("correo").setValue(correo);
        refUsuario.child("edad").setValue(edad)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful())
                        Toast.makeText(getContext(), "Perfil actualizado", Toast.LENGTH_SHORT).show();
                    else
                        Toast.makeText(getContext(), "Error al guardar", Toast.LENGTH_SHORT).show();
                });
    }
}
