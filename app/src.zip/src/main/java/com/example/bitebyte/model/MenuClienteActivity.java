package com.example.bitebyte.model;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

import com.example.bitebyte.R;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MenuClienteActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_cliente_bottom);

        BottomNavigationView bottomNav = findViewById(R.id.bottom_navigation);
        bottomNav.setOnItemSelectedListener(menuItem -> {
            int id = menuItem.getItemId();

            if (id == R.id.menu_cliente) {
                loadFragment(new FragmentMenuCliente());
            }
            else if (id == R.id.unirse_mesa) {
                startActivity(new Intent(MenuClienteActivity.this, UnirseMesaActivity.class));
            }
            else if (id == R.id.perfil_usuario) {
                loadFragment(new FragmentPerfilUsuario());
            }

            return true;  // indica que el click fue procesado
        });

        // Seleccionar por defecto la pestaña "Menú"
        bottomNav.setSelectedItemId(R.id.menu_cliente);
    }

    private void loadFragment(Fragment fragment) {
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.fragment_container, fragment)
                .commit();
    }
}
