package com.example.bitebyte.model;

public class Mesa {
    private String idMesa;
    private String idCocinero;
    private String idUsuario;  // ✅ Nuevo campo agregado

    public Mesa() {
        // Constructor vacío requerido por Firebase
    }

    public Mesa(String idMesa, String idCocinero, String idUsuario) {
        this.idMesa = idMesa;
        this.idCocinero = idCocinero;
        this.idUsuario = idUsuario;
    }

    public String getIdMesa() {
        return idMesa;
    }

    public void setIdMesa(String idMesa) {
        this.idMesa = idMesa;
    }

    public String getIdCocinero() {
        return idCocinero;
    }

    public void setIdCocinero(String idCocinero) {
        this.idCocinero = idCocinero;
    }

    public String getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(String idUsuario) {
        this.idUsuario = idUsuario;
    }
}
