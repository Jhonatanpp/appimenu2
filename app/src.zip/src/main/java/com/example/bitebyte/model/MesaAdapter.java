package com.example.bitebyte.model;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.example.bitebyte.R;
import java.util.List;

public class MesaAdapter extends RecyclerView.Adapter<MesaAdapter.ViewHolder> {

    private final Context context;
    private final List<Mesa> lista;

    public MesaAdapter(Context context, List<Mesa> lista) {
        this.context = context;
        this.lista = lista;
    }

    @NonNull @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context)
                .inflate(R.layout.item_mesa, parent, false);
        return new ViewHolder(view);
    }

    @Override public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Mesa m = lista.get(position);
        holder.txtId.setText("Mesa: " + m.getIdMesa());
        holder.txtUsuario.setText("Cliente: " + m.getIdUsuario());
        holder.txtCocinero.setText("Cocina: " + m.getIdCocinero());
    }

    @Override public int getItemCount() {
        return lista.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView txtId, txtUsuario, txtCocinero;
        ViewHolder(@NonNull View itemView) {
            super(itemView);
            txtId       = itemView.findViewById(R.id.itemMesaId);
            txtUsuario  = itemView.findViewById(R.id.itemMesaUsuario);
            txtCocinero = itemView.findViewById(R.id.itemMesaCocinero);
        }
    }
}
