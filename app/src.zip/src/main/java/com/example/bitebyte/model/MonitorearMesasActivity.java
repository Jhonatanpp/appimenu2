package com.example.bitebyte.model;

import android.os.Bundle;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.bitebyte.R;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.*;

import java.util.ArrayList;
import java.util.List;

public class MonitorearMesasActivity extends AppCompatActivity {

    private RecyclerView recyclerOrdenes;
    private OrdenAdapter ordenAdapter;
    private List<Orden> listaOrdenes;
    private DatabaseReference refOrdenes;
    private String idCocinero;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_monitorear_mesas);

        // Inicializar vistas
        recyclerOrdenes = findViewById(R.id.recyclerOrdenes);
        recyclerOrdenes.setLayoutManager(new LinearLayoutManager(this));

        // Inicializar lista y adapter
        listaOrdenes = new ArrayList<>();
        ordenAdapter = new OrdenAdapter(this, listaOrdenes);
        recyclerOrdenes.setAdapter(ordenAdapter);

        // Obtener ID del cocinero actual
        idCocinero = FirebaseAuth.getInstance().getCurrentUser().getUid();

        // Referencia a Firebase
        refOrdenes = FirebaseDatabase.getInstance().getReference("ordenes");

        cargarOrdenes();
    }

    private void cargarOrdenes() {
        refOrdenes.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                listaOrdenes.clear();
                for (DataSnapshot ds : snapshot.getChildren()) {
                    Orden orden = ds.getValue(Orden.class);
                    if (orden != null && orden.getIdCocinero() != null && orden.getIdCocinero().equals(idCocinero)) {
                        listaOrdenes.add(orden);
                    }
                }
                ordenAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(MonitorearMesasActivity.this, "Error al cargar las órdenes", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
