package com.example.bitebyte.model;

import java.io.Serializable;
import java.util.ArrayList;

public class Orden {

    private String id;
    private String idUsuario;
    private ArrayList<Plato> platos;
    private EstadoOrden estado;
    private String reseña;

    // Constructor vacío necesario para Firebase
    public Orden() {}

    // Constructor simple
    public Orden(String id, String idUsuario) {
        this.id = id;
        this.idUsuario = idUsuario;
        this.platos = new ArrayList<>();
        this.estado = EstadoOrden.PENDIENTE;
    }

    // Constructor completo
    public Orden(String id, String idUsuario, ArrayList<Plato> platos, EstadoOrden estado) {
        this.id = id;
        this.idUsuario = idUsuario;
        this.platos = platos;
        this.estado = estado;
    }

    // Métodos de acceso (getters y setters)
    public String getId() {
        return id;
    }

    public String getIdOrden() {
        return id; // Alias del ID
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(String idUsuario) {
        this.idUsuario = idUsuario;
    }

    public ArrayList<Plato> getPlatos() {
        return platos;
    }

    public void setPlatos(ArrayList<Plato> platos) {
        this.platos = platos;
    }

    public EstadoOrden getEstado() {
        return estado;
    }

    public void setEstado(EstadoOrden estado) {
        this.estado = estado;
    }

    public String getReseña() {
        return reseña;
    }

    public void setReseña(String reseña) {
        this.reseña = reseña;
    }

    // Agrega un plato a la orden
    public void agregarPlato(Plato plato) {
        if (platos == null) {
            platos = new ArrayList<>();
        }
        platos.add(plato);
    }

    // ✅ Método esperado por tus otras clases
    public ArrayList<Plato> getPlatosSeleccionados() {
        return platos;
    }
}