package com.example.bitebyte.model;

import android.app.AlertDialog;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.bitebyte.R;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.List;

public class OrdenAdapter extends RecyclerView.Adapter<OrdenAdapter.OrdenViewHolder> {

    private final Context context;
    private final List<Orden> listaOrdenes;

    public OrdenAdapter(Context context, List<Orden> listaOrdenes) {
        this.context = context;
        this.listaOrdenes = listaOrdenes;
    }

    @NonNull
    @Override
    public OrdenViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View vista = LayoutInflater.from(context).inflate(R.layout.item_order, parent, false);
        return new OrdenViewHolder(vista);
    }

    @Override
    public void onBindViewHolder(@NonNull OrdenViewHolder holder, int position) {
        Orden orden = listaOrdenes.get(position);
        holder.textOrden.setText("Mesa: " + orden.getCodigoMesa() + "\nUsuario: " + orden.getIdUsuario());
        holder.textEstadoOrden.setText("Estado: " + orden.getEstado().name());

        // Al hacer clic se despliega un diálogo para cambiar el estado
        holder.itemView.setOnClickListener(v -> mostrarDialogoEstado(orden));
    }

    @Override
    public int getItemCount() {
        return listaOrdenes.size();
    }

    private void mostrarDialogoEstado(Orden orden) {
        String[] opciones = {"EN_PREPARACION", "ENTREGADA"};

        new AlertDialog.Builder(context)
                .setTitle("Cambiar estado de la orden")
                .setItems(opciones, (dialog, which) -> {
                    EstadoOrden nuevoEstado = EstadoOrden.valueOf(opciones[which]);
                    orden.setEstado(nuevoEstado);

                    // Actualiza en Firebase
                    DatabaseReference ref = FirebaseDatabase.getInstance()
                            .getReference("ordenes")
                            .child(orden.getIdOrden());

                    ref.setValue(orden).addOnSuccessListener(aVoid ->
                            Toast.makeText(context, "Estado actualizado", Toast.LENGTH_SHORT).show()
                    ).addOnFailureListener(e ->
                            Toast.makeText(context, "Error al actualizar", Toast.LENGTH_SHORT).show()
                    );
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    public static class OrdenViewHolder extends RecyclerView.ViewHolder {
        TextView textOrden, textEstadoOrden;

        public OrdenViewHolder(@NonNull View itemView) {
            super(itemView);
            textOrden = itemView.findViewById(R.id.textOrden);
            textEstadoOrden = itemView.findViewById(R.id.textEstadoOrden);
        }
    }
}
