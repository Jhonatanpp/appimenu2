package com.example.bitebyte.model;

public enum EstadoOrden {
    PENDIENTE,
    EN_PROCESO,
    COMPLETADA,
    EN_PREPARACION,
    CANCELADA
}